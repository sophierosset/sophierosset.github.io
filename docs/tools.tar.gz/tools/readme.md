# Outils pour transformer du format BIO à xml et inversement
## xml-to-bio
- cat FILE.xml | awk -f xml-to-bio.awk

## BIO-to-xml
- cat FILE.bio | awk -f BIO-to-xml.awk

